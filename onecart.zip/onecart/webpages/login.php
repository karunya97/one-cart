<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Untitled document</title> 
        <link href="../css/login.css" rel="stylesheet" type="text/css"/>
        <link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
    </head>

    <body>
        <div class="signin">
        <form align=center>
            <h2 style="color:white"> Log In</h2>
            <input type="text" name="username" placeholder="Username">
            <input type="password" name="pass" placeholder="Password"><br><br>
            <a href="cong.php" ><input type="button" value="Log In"> </a><br><br>

            <div id="container">
            <a href="reset.php" style="margin-right:0px; font-size:13px; font-family:Tahoma, Geneva, sans-serif;"> Reset password </a>
            <a href="forget.php" style="margin-left:30px; font-size:13px; font-family:Tahoma, Geneva, sans-serif;"> Forgot password </a>
            </div><br><br><br><br><br><br>
            Don't have an account? <a href="signup.php" style="font-family:'Play, sans-serif;">&nbsp;Sign Up</a>

        </form>
        </div>
    </body>
</html>
 